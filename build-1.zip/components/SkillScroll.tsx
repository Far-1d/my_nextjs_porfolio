import React from 'react'
import { InfiniteMovingCards } from "./ui/infinite-moving-cards";
import { hobbies, skills_1, skills_2 } from '@/data';

const SkillScroll = () => {
  return (
    <div className='my-16' id="skills"> 
        <div className={"justify-items-center text-5xl font-bold text-neutral-600 dark:text-neutral-200 mb-2 mt-2 flex items-start justify-center"}>
            {/* <div className="flex items-center mr-2 mt-1">
                <IoIosFitness />
            </div> */}
            <div className="flex">
            <h1 className="heading">
                My {' '}
                <span className="text-purple">Skills</span>
            </h1>
            </div>
        </div>
        <div className='w-5/6 md:w-3/4 mx-auto mt-16' >
            <div className='w-full md:w-4/5 mx-auto py-4'>
                <InfiniteMovingCards
                    items={skills_1}
                    direction="right"
                    speed="normal"
                />
            </div>
            <div className='w-full md:w-4/5 mx-auto py-2'>
                <InfiniteMovingCards
                    items={skills_2}
                    direction="left"
                    speed="normal"
                />
            </div>
            {/* <div className='w-3/4 mx-auto py-6'>
                <InfiniteMovingCards
                    items={hobbies}
                    direction="right"
                    speed="normal"
                />
            </div> */}
        </div>
    </div>
  )
}

export default SkillScroll