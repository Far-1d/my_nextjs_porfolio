import React from 'react'
import { BentoGrid, BentoGridItem } from './ui/BentoGrid'
import { gridItems } from '@/data'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/shadcn/dialog"
import MagicButton from './ui/MagicButton'

const Grid = () => {
  return (
    <section id='about'>
        <BentoGrid>
            {gridItems.map ( ({id, title, description, className, 
                titleClassName}) => (
                <BentoGridItem
                    id={id}
                    key={id}
                    title={title}
                    description={description}
                    className={className}
                    titleClassName={titleClassName}
                />
            ))}
        </BentoGrid>
        
        <div className='flex items-center justify-center mx-16 sm:mx-32 md:mx-auto pt-8 md:pt-2'>
          <Dialog>
            <DialogTrigger asChild>
              <MagicButton title={'See more'}></MagicButton>
            </DialogTrigger>
          
            <DialogTrigger asChild={false} />
            <DialogContent>
              <DialogHeader>
                <DialogTitle>More About Me</DialogTitle>
                <DialogDescription>
                  <p className='pt-4'>
                  From university when studying mechanical engineering up until now that i am following a path of becoming a python senior developer, i never stopped from learning and i always wanted more and wanted to grow higher.
                  <br /><br />
                  My success in starting a new path and with completing many freelance projects during last year and passing the tough starting times, i can say that my passion for programming was a true one.
                  <br /><br />
                  I also peaked into writing trade robots and EA using C and Mql and beside that i enjoy doing 3D designs using blender. as a self-taught developer i can tell there is no limit in learning new skills. 
                  <br /><br />
                  Loving freelance work i see that it is time for me to go on a more stable career, enjoying my grow with other people and helping others grow too. for me an Always evolving, intimate environment with meritocratic policies is a dream coming true. 
                  </p>
                </DialogDescription>
              </DialogHeader>
            </DialogContent>
          </Dialog>
        </div>
          
    </section>
  )
}

export default Grid